const { zokou } = require(__dirname + "/../framework/zokou");
const moment = require("moment-timezone");
const set = require(__dirname + "/../set");

moment.tz.setDefault(set.TZ);

zokou(
  {
    nomCom: "ping",
    categorie: "General",
  },
  async (dest, zk, { ms }) => {
    const ping = Date.now() - ms.messageTimestamp * 1000;
    const time = moment().format("HH:mm");

    const message = `╭━━❖ *«• PING TEST •»* ❖━━⬣
┃🤖 BOT: DULLAH-XMD
┃⚡ PING: ${ping}MS 🕐
╰━━━━━━⊱『DULLAH』⊰━━━━━━⬣
> ©Dullahxmd is Speed🔥
🕘 ${time}`;

    await zk.sendMessage(dest, {
      text: message,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363402252728845@newsletter",
          newsletterName: "DULLAH-XMD",
          serverMessageId: -1
        }
      }
    }, { quoted: ms });
  }
);
