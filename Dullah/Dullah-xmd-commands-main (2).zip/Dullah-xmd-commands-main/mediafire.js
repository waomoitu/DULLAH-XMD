const { zokou } = require("../framework/zokou");

zokou({
    nomCom: "mediafire",
    alias: ["mfire"],
    desc: "Download mediafire file",
    category: "download",
    use: '<url>',
    },  async exec(msg, sock, args) {
    let match = isUrl(args[0] || msg.quoted?.text);
    if (!match) return msg.reply('*Example:* mediafire <url>');

    const result = await mediafire(match);
    if (!result) return msg.reply('*Not found*');

    return sock.sendMessage(msg.from, { document: { url: result }, mimetype: 'application/octet-stream' }, { quoted: msg });
  }
};
