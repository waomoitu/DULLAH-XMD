const axios = require("axios");
const { zokou } = require("../framework/zokou");

// Helper function: ISO alpha2 → Flag emoji
function getFlagEmoji(countryCode) {
  if (!countryCode) return "";
  return countryCode
    .toUpperCase()
    .split("")
    .map(letter => String.fromCodePoint(letter.charCodeAt(0) + 127397))
    .join("");
}

zokou(
  {
    nomCom: "check",
    categorie: "Utility",
    reaction: "🌍",
    desc: "Checks the country calling code and returns the corresponding country name(s) with flag",
  },
  async (dest, zk, commandeOptions) => {
    const { repondre, arg } = commandeOptions;

    try {
      let code = arg[0];
      if (!code) {
        return repondre("❌ Please provide a country code. Example: `.check 263`");
      }

      // Normalize input: remove '+' signs
      code = code.replace(/\+/g, "");

      // Fetch minimal country data
      const url = "https://restcountries.com/v3.1/all?fields=idd,cca2,name";
      const { data } = await axios.get(url);

      // Find matches
      const matchingCountries = data.filter(country => {
        if (country.idd?.root && country.idd?.suffixes) {
          return country.idd.suffixes.some(suffix => {
            let fullCode = (country.idd.root + suffix).replace(/\+/g, "");
            return fullCode === code;
          });
        }
        return false;
      });

      if (matchingCountries.length > 0) {
        const countryNames = matchingCountries
          .map(country => `${getFlagEmoji(country.cca2)} ${country.name.common}`)
          .join("\n");
        repondre(`✅ *Country Code*: +${code}\n🌍 *Countries*:\n${countryNames}`);
      } else {
        repondre(`❌ No country found for the code +${code}.`);
      }
    } catch (error) {
      console.error("API Error:", error.message || error);
      repondre("❌ An error occurred while checking the country code (API or connection issue).");
    }
  }
);