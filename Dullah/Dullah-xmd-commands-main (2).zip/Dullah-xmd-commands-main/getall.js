const { zokou } = require("../framework/zokou");
const set = require("../set");

zokou({
    nomCom: "getall",
    desc: "Get JID of all members of groups / personal chats / all groups.",
    categorie: "General",
    reaction: "📍",
    fromMe: true,
    filename: __filename,
    public: false,
}, 
async (chatId, zk, { repondre, ms, arg }) => {
    try {
        let str = "";
        let cd = (arg[0] || "").toLowerCase();   // pc | gc | members

        // ====== GROUP MEMBERS ======
        if (["members","member","m"].includes(cd)) {
            if (!chatId.endsWith("@g.us")) {
                return repondre("⚠️ This command works in groups only!");
            }

            const groupMetadata = await zk.groupMetadata(chatId);
            const participants = groupMetadata.participants || [];

            for (const member of participants) {
                const id = member.id;
                const number = id.split("@")[0];
                str += `📍 +${number}\n🔗 https://wa.me/${number}\n\n`;
            }

            return repondre(
                str 
                  ? `*「 LIST OF GROUP MEMBER NUMBERS 」*\n\nTotal: ${participants.length} members.\n\n${str}`
                  : "*No members found!*"
            );
        }

        // ====== PERSONAL CHATS ======
        else if (["user","pm","pc","u"].includes(cd)) {
            let contacts = zk.store?.contacts || zk.contacts || {};
            let anu = Object.keys(contacts).filter(v => v.endsWith("@s.whatsapp.net"));

            for (let i of anu) { 
                let num = i.split("@")[0];
                str += `📍 +${num}\n🔗 https://wa.me/${num}\n\n`; 
            }

            return repondre(
                str 
                  ? `*「 LIST OF PERSONAL CHAT NUMBERS 」*\n\nTotal: ${anu.length} users.\n\n${str}` 
                  : "*No personal chats found!*"
            );
        }

        // ====== GROUPS LIST ======
        else if (["group","groups","gc","g"].includes(cd)) {
            let n = await zk.groupFetchAllParticipating();
            const groups = Object.values(n);

            for (let g of groups) {  
                let link = "";
                try {
                    let code = await zk.groupInviteCode(g.id);
                    link = `https://chat.whatsapp.com/${code}`;
                } catch {
                    link = "(⚠️ Bot cannot fetch link)";
                }

                str += `📍 *${g.subject}*\nID: ${g.id}\n🔗 Link: ${link}\n\n`;
            } 

            return repondre(
                str 
                  ? `*「 LIST OF GROUP CHATS 」*\n\nTotal: ${groups.length} groups.\n\n${str}` 
                  : "*No groups found!*"
            );
        }

        // ====== HELP ======
        else {
            return repondre(`*Usage:* ${set.PREFIXE}getall members | pc | gc`);
        }

    } catch (e) {
        repondre(`❌ Error: ${e.message}`);
        console.error("Command getall error:", e);
    }
});
