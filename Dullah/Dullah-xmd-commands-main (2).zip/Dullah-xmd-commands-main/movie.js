const { zokou } = require("../framework/zokou");
const axios = require("axios");

zokou(
{
    nomCom: "movie",
    categorie: "utility",
    reaction: "🎬",
    desc: "Fetch detailed information about a movie.",
}, async (dest, zk, commandeOptions) => {
  const { arg, repondre , ms } = commandeOptions;

  if (!arg[0] || arg === "") {
    repondre("give the name of a series or film.");
    return;
  }

        // Call the API
        const apiUrl = `https://apis.davidcyriltech.my.id/imdb?query=${encodeURIComponent(movieName)}`;
        const response = await axios.get(apiUrl);

        if (!response.data?.status || !response.data?.movie) {
            console.log("API response invalid:", response.data);
            return reply("🚫 Movie not found. Please check the name and try again.");
        }

        const movie = response.data.movie;

        // Safe Rotten Tomatoes rating
        const rtRating = movie.ratings?.find(r => r.source === 'Rotten Tomatoes')?.value || 'N/A';

        // Format caption
        const dec = `
🎬 ${movie.title} (${movie.year}) ${movie.rated || ''}

⭐ IMDb: ${movie.imdbRating || 'N/A'} | 🍅 Rotten Tomatoes: ${rtRating} | 💰 Box Office: ${movie.boxoffice || 'N/A'}

📅 Released: ${movie.released ? new Date(movie.released).toLocaleDateString() : 'N/A'}
⏳ Runtime: ${movie.runtime || 'N/A'}
🎭 Genre: ${movie.genres || 'N/A'}

📝 Plot: ${movie.plot || 'N/A'}

🎥 Director: ${movie.director || 'N/A'}
✍️ Writer: ${movie.writer || 'N/A'}
🌟 Actors: ${movie.actors || 'N/A'}

🌍 Country: ${movie.country || 'N/A'}
🗣️ Language: ${movie.languages || 'N/A'}
🏆 Awards: ${movie.awards || 'None'}

View on IMDb
`;

        // Send message with image, caption, and original channel info
        await zk.sendMessage(
            dest,
            {
                image: {
                    url: movie.poster && movie.poster !== "N/A" ? movie.poster : "https://files.catbox.moe/7zfdcq.jpg"
                },
                caption: dec,
                contextInfo: {
                    mentionedJid: [sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363354023106228@newsletter",
                        newsletterName: "JawadTechX",
                        serverMessageId: 143
                    }
                }
            },
            { quoted: ms }
        );

    } catch (e) {
        console.error("Movie command error:", e);
        reply(`❌ Error: ${e.message}`);
    }
});
