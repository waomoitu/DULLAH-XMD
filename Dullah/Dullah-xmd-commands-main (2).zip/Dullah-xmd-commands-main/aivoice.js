const { zokou } = require("../framework/zokou");
const axios = require("axios");

zokou(
  {
    nomCom: "aivoice",
    categorie: "fun",
    reaction: "🪃",
    desc: "Text to speech with different AI voices",
  },
  async (dest, zk, commandeOptions) => {
    const { repondre, arg, ms } = commandeOptions;

    try {
      if (!arg || arg.length === 0) {
        return repondre("❎ Please provide text after the command.\n\nExample: .aivoice hello");
      }

      const inputText = arg.join(" ");

      // Voice model menu
      const voiceModels = [
        { number: "1", name: "Hatsune Miku", model: "miku" },
        { number: "2", name: "Nahida (Exclusive)", model: "nahida" },
        { number: "3", name: "Nami", model: "nami" },
        { number: "4", name: "Ana (Female)", model: "ana" },
        { number: "5", name: "Optimus Prime", model: "optimus_prime" },
        { number: "6", name: "Goku", model: "goku" },
        { number: "7", name: "Taylor Swift", model: "taylor_swift" },
        { number: "8", name: "Elon Musk", model: "elon_musk" },
        { number: "9", name: "Mickey Mouse", model: "mickey_mouse" },
        { number: "10", name: "Kendrick Lamar", model: "kendrick_lamar" },
        { number: "11", name: "Angela Adkinsh", model: "angela_adkinsh" },
        { number: "12", name: "Eminem", model: "eminem" }
      ];

      let menuText = "╭━━━〔 *AI VOICE MODELS* 〕━━━⊷\n";
      voiceModels.forEach(model => {
        menuText += `┃▸ ${model.number}. ${model.name}\n`;
      });
      menuText += "╰━━━⪼\n\n";
      menuText += `📌 *Reply with the number to select voice model for:*\n"${inputText}"`;

      const sentMsg = await zk.sendMessage(dest, {
        image: { url: "https://files.catbox.moe/3v4ezj.jpeg" },
        caption: menuText,
      }, { quoted: ms });

      const messageID = sentMsg.key.id;
      let handlerActive = true;

      const handlerTimeout = setTimeout(() => {
        handlerActive = false;
        zk.ev.off("messages.upsert", messageHandler);
        repondre("⌛ Voice selection timed out. Please try the command again.");
      }, 120000);

      const messageHandler = async (msgData) => {
        if (!handlerActive) return;

        const receivedMsg = msgData.messages[0];
        if (!receivedMsg || !receivedMsg.message) return;

        const receivedText = receivedMsg.message.conversation ||
          receivedMsg.message.extendedTextMessage?.text;

        const senderID = receivedMsg.key.remoteJid;
        const isReplyToBot = receivedMsg.message.extendedTextMessage?.contextInfo?.stanzaId === messageID;

        if (isReplyToBot && senderID === dest) {
          clearTimeout(handlerTimeout);
          zk.ev.off("messages.upsert", messageHandler);
          handlerActive = false;

          const selectedNumber = receivedText.trim();
          const selectedModel = voiceModels.find(model => model.number === selectedNumber);

          if (!selectedModel) {
            return repondre("❌ Invalid option! Please reply with a number from the menu.");
          }

          try {
            await repondre(`🔊 Generating audio with ${selectedModel.name} voice...`);

            const apiUrl = `https://api.agatz.xyz/api/voiceover?text=${encodeURIComponent(inputText)}&model=${selectedModel.model}`;
            const response = await axios.get(apiUrl, { timeout: 30000 });

            const data = response.data;
            if (data.status === 200) {
              await zk.sendMessage(dest, {
                audio: { url: data.data.oss_url },
                mimetype: "audio/mpeg",
              }, { quoted: receivedMsg });
            } else {
              repondre("❌ Error generating audio. Please try again.");
            }
          } catch (error) {
            console.error("API Error:", error);
            repondre("❌ Error processing your request. Please try again.");
          }
        }
      };

      zk.ev.on("messages.upsert", messageHandler);

    } catch (error) {
      console.error("Command Error:", error);
      repondre("❌ An error occurred. Please try again.");
    }
  }
);
