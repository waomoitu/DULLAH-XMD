const fs = require("fs");
const path = require("path");
const { zokou } = require("../framework/zokou");

zokou({
  nomCom: "dulla",
  categorie: "General",
  reaction: "🌟",
  nomFichier: __filename,
}, async (dest, zk, { repondre, ms }) => {
  try {
    const stickerPath = path.resolve(__dirname, "../media/dulla.webp");
    const buffer = fs.readFileSync(stickerPath);

    await zk.sendMessage(
      dest,
      { sticker: buffer },
      { quoted: ms }
    );

  } catch (e) {
    console.error("❌ Error sending sticker:", e);
    await repondre("❌ Failed to send the *DULLA* animated sticker.\nError: " + e.message);
  }
});
