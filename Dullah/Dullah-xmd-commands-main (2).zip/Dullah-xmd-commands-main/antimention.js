const { zokou } = require("../framework/zokou");
const fs = require("fs");
const path = require("path");

const antimentionPath = path.join(__dirname, "../bdd/antimention.json");

zokou(
  {
    nomCom: "antimention",
    categorie: "General",
    reaction: "🚫",
    desc: "Enable or disable antimention protection",
    fromMe: true,
  },
  async (dest, zk, commandeOptions) => {
    const { repondre, arg, ms } = commandeOptions;

    const chatId = ms.chat || (ms.key && ms.key.remoteJid) || "";

    // Check if chat is a group
    if (!chatId.endsWith("@g.us")) {
      return repondre("❌ This command only works in groups.");
    }

    // Validate argument
    if (!arg[0] || !["on", "off"].includes(arg[0].toLowerCase())) {
      return repondre("*❗ Usage:* .antimention on | .antimention off");
    }

    const status = arg[0].toLowerCase();

    // Load config
    let config = {};
    if (fs.existsSync(antimentionPath)) {
      try {
        config = JSON.parse(fs.readFileSync(antimentionPath, "utf-8"));
      } catch {
        config = {};
      }
    }

    if (status === "on") {
      config[chatId] = "on";
      await repondre("✅ Antimention protection enabled in this group.");
    } else {
      delete config[chatId];
      await repondre("❌ Antimention protection disabled in this group.");
    }

    fs.writeFileSync(antimentionPath, JSON.stringify(config, null, 2));
  }
);
