const { zokou } = require('../framework/zokou');
const os = require('os');
const moment = require('moment-timezone');

const audioURL = "https://files.catbox.moe/9txwnm.mp3"; // background music

zokou({
  nomCom: 'alive',
  categorie: 'General'
}, async (dest, zk, commandeOptions) => {
  const { ms, repondre, nomAuteurMessage } = commandeOptions;

  moment.tz.setDefault('Africa/Nairobi');

  let uptime = process.uptime();

  if (uptime < 60) {
    const randomMinutes = Math.floor(Math.random() * 5) + 1;
    uptime = randomMinutes * 60;
  }

  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);

  const totalRAM = os.totalmem() / 1024 / 1024;
  const usedRAM = process.memoryUsage().rss / 1024 / 1024;

  const caption = `╭──────◆
│👻 *Hi....* ${nomAuteurMessage.toUpperCase()} 👋*
│
│⏳ *Uptime:* ${hours} hour${hours !== 1 ? 's' : ''} ${minutes} minute${minutes !== 1 ? 's' : ''} ${seconds} second${seconds !== 1 ? 's' : ''}
│📟 *Ram:* ${usedRAM.toFixed(2)}MB / ${totalRAM.toFixed(2)}MB
╰──────◆

「 DULLAH-XMD IS ONLINE ✅ 」
🔗 *Bot link:* https://github.com/abdallahsalimjuma/DULLAH-XMD  
👥 *Group:* https://chat.whatsapp.com/Ehjd0PLNVLNLtgI01Eqh8D?mode=ems_copy_t

*Thanks for trusting DULLAH-XMD 💫*`;

  try {
    // Send alive message with NO link preview
    await zk.sendMessage(dest, {
      text: caption,
      linkPreview: false
    }, {
      quoted: ms,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true
      }
    });

    // Send background audio
    await zk.sendMessage(dest, {
      audio: { url: audioURL },
      mimetype: 'audio/mpeg',
      ptt: false
    }, {
      quoted: ms,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true
      }
    });

  } catch (e) {
    console.error("Alive error: ", e);
    repondre("❌ Error showing alive menu or sending music. Please check your paths or internet connection.");
  }
});
