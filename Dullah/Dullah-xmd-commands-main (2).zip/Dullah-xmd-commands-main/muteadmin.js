const { zokou } = require("../framework/zokou");
const moment = require("moment-timezone");

zokou({
  nomCom: "muteadmin",
  categorie: "Group",
  reaction: "👨🏿‍💼"
}, async (dest, zk, commandeOptions) => {
  let {
    repondre,
    msgRepondu,
    infosGroupe,
    auteurMsgRepondu,
    verifGroupe,
    auteurMessage,
    superUser,
    idBot,
    msg
  } = commandeOptions;

  if (!verifGroupe) return repondre("This command can only be used in groups.");

  let groupMembers = await infosGroupe.participants;

  const isMember = (user) => groupMembers.some(m => m.id === user);
  const getAdmins = (members) => members.filter(m => m.admin != null).map(m => m.id);

  let admins = getAdmins(groupMembers);
  let isTargetAdmin = admins.includes(auteurMsgRepondu);
  let isTargetMember = isMember(auteurMsgRepondu);
  let isSenderAdmin = admins.includes(auteurMessage);
  let isBotAdmin = admins.includes(idBot);

  try {
    if (isSenderAdmin || superUser) {
      if (msgRepondu) {
        if (isBotAdmin) {
          if (isTargetMember) {
            if (!isTargetAdmin) {
              return repondre("The mentioned user is not a group admin.");
            } else {
              await zk.groupParticipantsUpdate(dest, [auteurMsgRepondu], "demote");

              const now = moment().tz('Africa/Nairobi');
              const fullDate = now.format("M/D/YYYY, h:mm:ss A");
              const groupName = infosGroupe.subject;
              const removedBy = `@${auteurMessage.split("@")[0]}`;
              const removedUser = `@${auteurMsgRepondu.split("@")[0]}`;

              // ✅ Confirmation message (replying to the command `.muteadmin`)
              const successMsg = await zk.sendMessage(dest, {
                text: `✅ Successfully muteadmined ${removedUser} to a normal member.`,
                mentions: [auteurMsgRepondu],
                quoted: msg
              });

              // 📨 Admin event message (replies to the success message)
              const forwardMsg = `*DULLAH XMD Admin Event*\n\n${removedBy} has muteadmined ${removedUser} from admin. 👀\n\n📅 *Date:* ${fullDate}\n👥 *Group:* ${groupName}`;

              await zk.sendMessage(dest, {
                text: forwardMsg,
                mentions: [auteurMsgRepondu, auteurMessage],
                quoted: successMsg.key
              });

              return;
            }
          } else {
            return repondre("The mentioned user is not in the group.");
          }
        } else {
          return repondre("Sorry, I am not an admin in this group.");
        }
      } else {
        return repondre("Please mention or reply to the user you want to muteadmin.");
      }
    } else {
      return repondre("You must be a group admin to use this command.");
    }
  } catch (e) {
    return repondre("An error occurred: " + e);
  }
});
