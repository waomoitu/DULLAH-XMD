const { zokou } = require("../framework/zokou");
const fs = require("fs");
const path = require("path");

const antistickerFile = path.join(__dirname, "../data/antisticker.json");

// Load antisticker data
function loadAntiSticker() {
if (!fs.existsSync(antistickerFile)) return { groups: {} };
return JSON.parse(fs.readFileSync(antistickerFile));
}

// Save antisticker data
function saveAntiSticker(data) {
fs.writeFileSync(antistickerFile, JSON.stringify(data, null, 2));
}

// Helper: Check if sender is group admin
async function isGroupAdmin(zk, groupId, participant) {
try {
const metadata = await zk.groupMetadata(groupId);
const admins = metadata.participants.filter(p => p.admin !== null).map(p => p.id);
return admins.includes(participant);
} catch {
return false;
}
}

// Command to enable/disable antisticker
zokou({
nomCom: "antisticker",
categorie: "Group",
reaction: "❌",
}, async (dest, zk, commandeOptions) => {
const { repondre, arg, ms } = commandeOptions;
const groupId = ms.key.remoteJid;
const sender = ms.key.participant;

if (!groupId.endsWith("@g.us")) {
return repondre("❗This command can only be used in group chats.");
}

if (!await isGroupAdmin(zk, groupId, sender)) {
return repondre("⛔Only group admins can use this command.");
}

const data = loadAntiSticker();
const action = (arg[0] || "").toLowerCase();

if (action === "on") {
data.groups = data.groups || {};
data.groups[groupId] = { active: true };
saveAntiSticker(data);
repondre("✅ Antisticker has been activated for this group.");
} else if (action === "off") {
if (data.groups && data.groups[groupId]) {
delete data.groups[groupId];
saveAntiSticker(data);
repondre("❎ Antisticker has been deactivated for this group.");
} else {
repondre("ℹ️ Antisticker is not active in this group.");
}
} else {
repondre("⚠️ Usage: antisticker on / off");
}
});



