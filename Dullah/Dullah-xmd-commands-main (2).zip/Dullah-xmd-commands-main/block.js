const { zokou } = require("../framework/zokou");

// 🚫 BLOCK
zokou(
  {
    nomCom: "block",
    categorie: "Owner",
    reaction: "🚫",
    desc: "Block a user (owner only)"
  },
  async (dest, zk, { repondre, msgRepondu, mention, arg, auteurMessage, auteurMsgRepondu, superUser }) => {
    if (!superUser) return repondre("❌ Only the bot owner can use this command.");

    let jid;
    if (msgRepondu) {
      jid = auteurMsgRepondu; // reply
    } else if (mention && mention.length > 0) {
      jid = mention[0]; // mention
    } else if (arg[0] && arg[0].includes("@")) {
      jid = arg[0].replace(/[@\s]/g, "") + "@s.whatsapp.net"; // manual
    } else {
      jid = dest; // DM inbox fallback
    }

    await zk.updateBlockStatus(jid, "block")
      .then(() => repondre(`*@${jid.split("@")[0]} has been BLOCKED ⛔*`, { mentions: [jid] }))
      .catch(e => {
        console.error("Block error:", e);
        repondre("❌ Failed to block this user.");
      });
  }
);

// 🔓 UNBLOCK
zokou(
  {
    nomCom: "unblock",
    categorie: "Owner",
    reaction: "🔓",
    desc: "Unblock a user (owner only)"
  },
  async (dest, zk, { repondre, msgRepondu, mention, arg, auteurMessage, auteurMsgRepondu, superUser }) => {
    if (!superUser) return repondre("❌ Only the bot owner can use this command.");

    let jid;
    if (msgRepondu) {
      jid = auteurMsgRepondu;
    } else if (mention && mention.length > 0) {
      jid = mention[0];
    } else if (arg[0] && arg[0].includes("@")) {
      jid = arg[0].replace(/[@\s]/g, "") + "@s.whatsapp.net";
    } else {
      jid = dest;
    }

    await zk.updateBlockStatus(jid, "unblock")
      .then(() => repondre(`*@${jid.split("@")[0]} has been UNBLOCKED ✅*`, { mentions: [jid] }))
      .catch(e => {
        console.error("Unblock error:", e);
        repondre("❌ Failed to unblock this user.");
      });
  }
);
