const { zokou } = require("../framework/zokou");
const { eco, sck } = require("../lib");

zokou({
  nomCom: "deposit",
  desc: "deposit gold.",
  categorie: "economy",
  reaction: "💷"
}, async (dest, zk, commandeOptions) => {
  const { texte, auteurMessage, nomAuteurMessage, repondre } = commandeOptions;

  try {
    let zerogroup = (await sck.findOne({ id: dest })) || {};
    let mongoschemas = zerogroup.economy || "false";
    if (mongoschemas === "false") return repondre("*🚦Economy* is not active in current group.");

    if (!texte) return repondre("Baka!! Provide the 💰amount you want to deposit!");

    let d = parseInt(texte);
    if (isNaN(d) || d <= 0) return repondre("🚫 Invalid amount. Please enter a valid number!");

    const deposit = await eco.deposit(auteurMessage, "Suhail", d);
    const balance = await eco.balance(auteurMessage, "Suhail");

    if (deposit.noten) return repondre("You can't deposit what you don't have💰.");

    return repondre(`⛩️ Sender: ${nomAuteurMessage}\n🍀Successfully 💰Deposited 🪙${deposit.amount} to your bank. Upgrade your bank capacity to add more money📈.`);

  } catch (e) {
    console.error(e);
    return repondre(`⚠️ Error: ${e.message || e}\n\nCommand: deposit`);
  }
});