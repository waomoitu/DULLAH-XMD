const { zokou } = require("../framework/zokou");
const { setStatus, getStatus } = require("../bdd/antitagadmin");

zokou({
  nomCom: "antitagadmin",
  categorie: "Group",
  reaction: "🚨"
}, async (dest, zk, commandeOptions) => {
  const { arg, verifGroupe, verifAdmin, superUser, repondre } = commandeOptions;

  if (!verifGroupe) return repondre("❗ This command can only be used in groups.");
  if (!verifAdmin && !superUser) return repondre("⛔ Only group admins can use this command.");

  const jid = dest;
  const action = (arg[0] || "").toLowerCase();

  if (action === "on") {
    setStatus(jid, true);
    return repondre("✅ *AntiTagAdmin* has been *enabled*.\n\nIf a user tags an admin, action will be taken.");
  }

  if (action === "off") {
    setStatus(jid, false);
    return repondre("❌ *AntiTagAdmin* has been *disabled.*");
  }

  const status = getStatus(jid) ? "✅ Enabled" : "❌ Disabled";
  return repondre(`📌 Current status: ${status}\n\nUsage:\n- *antitagadmin on*\n- *antitagadmin off*`);
});
