const { zokou } = require("../framework/zokou");
const db = require("../lib/db");

// Command: .listactive
zokou({
nomCom: "listactive",
categorie: "Group",
reaction: "📊",
nomFichier: __filename,
}, async (msg, zk, { repondre, ms }) => {
const groupId = ms.key.remoteJid;
if (!groupId.endsWith("@g.us")) return await repondre("❌ This command works only in groups.");

db.all("SELECT userId, count FROM activity WHERE chatId = ? ORDER BY count DESC LIMIT 20", [groupId], async (err, rows) => {
if (err) return await repondre("❌ DB Error.");
if (!rows || rows.length === 0) return await repondre("⚠️ No activity found yet in this group.");

const metadata = await zk.groupMetadata(groupId);  
let msgText = "🔥 *Top Active Members:*\n\n";  
let total = 0, i = 1, mentions = [];  

for (const row of rows) {  
  let displayName = row.userId.split("@")[0];  
  try {  
    const p = metadata.participants.find(p => p.id === row.userId);  
    if (p) displayName = p.notify || p.name || p.pushname || displayName;  
  } catch {}  

  msgText += `🔹 ${i++}. @${displayName} — *${row.count} messages*\n`;  
  mentions.push(row.userId);  
  total += row.count;  
}  

msgText += `\n📊 *Total Tracked Messages:* ${total}`;  
msgText += `\n\n💡 _Use *.myrank* to check your rank or *.resetactivity* to reset._`;  

await zk.sendMessage(groupId, { text: msgText, mentions }, { quoted: ms });

});
});

// Command: .myrank
zokou({
nomCom: "myrank",
categorie: "Group",
reaction: "🎖️",
nomFichier: __filename,
}, async (msg, zk, { repondre, ms }) => {
const groupId = ms.key.remoteJid;
const senderId = ms.key.participant || ms.key.remoteJid;
if (!groupId.endsWith("@g.us")) return await repondre("❌ This command works only in groups.");

db.all("SELECT userId, count FROM activity WHERE chatId = ? ORDER BY count DESC", [groupId], async (err, rows) => {
if (err) return await repondre("❌ DB Error.");

const rank = rows.findIndex(row => row.userId === senderId) + 1;  
const user = rows.find(row => row.userId === senderId);  

if (!user) return await repondre("⚠️ You don't have any activity yet.");  

await repondre(`🎖️ *Your Rank:* #${rank}\n💬 *Messages Sent:* ${user.count}`);

});
});

// Command: .resetactivity
zokou({
nomCom: "resetactivity",
categorie: "Group",
reaction: "♻️",
nomFichier: __filename,
}, async (msg, zk, { repondre, ms }) => {
const groupId = ms.key.remoteJid;
if (!groupId.endsWith("@g.us")) return await repondre("❌ This command works only in groups.");

db.run("DELETE FROM activity WHERE chatId = ?", [groupId], async (err) => {
if (err) return await repondre("❌ Failed to reset activity.");
await repondre("✅ Group activity has been reset.");
});
});
