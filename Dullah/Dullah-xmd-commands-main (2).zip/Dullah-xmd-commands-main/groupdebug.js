const { zokou } = require("../framework/zokou");

zokou(
  {
    nomCom: "groupdebug",
    categorie: "Group",
    reaction: "🔍",
  },
  async (dest, zk, { repondre, ms }) => {
    try {
      const metadata = await zk.groupMetadata(dest);
      const admins = metadata.participants
        .filter((p) => p.admin !== null)
        .map((p) => `${p.id} (${p.admin})`);

      const isBotAdmin = metadata.participants.find(
        (p) => p.id === zk.user.id
      )?.admin;

      repondre(
        `🧪 *Group Debug Info:*\n\n🤖 Bot ID: ${zk.user.id}\n👑 Bot Admin Status: ${isBotAdmin}\n\n👥 Admins:\n${admins.join("\n")}`
      );
    } catch (e) {
      console.log(e);
      repondre("❌ Error while fetching group info.");
    }
  }
);
