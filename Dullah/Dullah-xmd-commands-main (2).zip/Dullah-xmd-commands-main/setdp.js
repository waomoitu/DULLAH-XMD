const { zokou } = require('../framework/zokou');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// Convert a stream to buffer
async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

zokou({
    nomCom: "setdp",
    categorie: "Group",
    reaction: "🖼️",
    nomFichier: __filename
}, async (dest, zk, { ms, repondre, auteurMessage, infosGroupe }) => {

    // Allow only in group chats
    if (!dest.endsWith('@g.us')) {
        return repondre("❌ This command only works in group chats.");
    }

    // Allow only group admins
    const isUserAdmin = infosGroupe?.participants?.find(p => p.id === auteurMessage)?.admin;
    if (!isUserAdmin) {
        return repondre("⛔ Only group admins can use this command.");
    }

    // Reject if it's a reply to an image
    if (ms.quoted && (ms.quoted.message?.imageMessage ||
                      ms.quoted.message?.ephemeralMessage?.message?.imageMessage ||
                      ms.quoted.message?.viewOnceMessageV2?.message?.imageMessage)) {
        return repondre("❌ This command only works when you send an image directly, not by replying.");
    }

    // Accept only directly sent image
    const imageMsg = ms.message?.imageMessage;

    if (!imageMsg) {
        return repondre("🖼️ Please send an image directly with this command to set as group profile picture.");
    }

    try {
        const stream = await downloadContentFromMessage(imageMsg, 'image');
        const buffer = await streamToBuffer(stream);
        await zk.updateProfilePicture(dest, buffer);
        await repondre("✅ Group profile picture updated successfully!");
    } catch (error) {
        console.error("Error:", error);
        return repondre("❌ Failed to update group profile picture.");
    }
});
