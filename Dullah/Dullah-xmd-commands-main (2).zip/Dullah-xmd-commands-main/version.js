const { zokou } = require("../framework/zokou");
const axios = require("axios");
const os = require("os");
const fs = require("fs");
const path = require("path");

// Hardcoded bot version & changelog
const BOT_VERSION = "2.0.0";
const CHANGELOG = "🔥 Initial release of Dullahxmd.\n- Added YouTube, Play, TTS, Sticker, Group tools.\n- Fixed minor bugs.";

// Helper function for uptime
function runtime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return `${hours}h ${minutes}m ${secs}s`;
}

zokou(
  {
    nomCom: "version",
    alias: ["changelog", "cupdate", "checkupdate"],
    categorie: "General",
    reaction: "🚀",
    desc: "Check bot's version, system stats, and update info."
  },
  async (dest, zk, { repondre, pushName }) => {
    try {
      // Local version
      let localVersion = BOT_VERSION;
      let changelog = CHANGELOG;

      // Fetch latest version data from GitHub (optional)
      const rawVersionUrl = "https://raw.githubusercontent.com/abdallahsalimjuma/DULLAH-XMD/main/data/version.json";
      let latestVersion = BOT_VERSION;
      let latestChangelog = CHANGELOG;
      try {
        const { data } = await axios.get(rawVersionUrl);
        if (data.version) latestVersion = data.version;
        if (data.changelog) latestChangelog = data.changelog;
      } catch (error) {
        console.error("Failed to fetch latest version:", error);
      }

      // Count total plugins
      const pluginPath = path.join(__dirname, "../dullah");
      const pluginFiles = fs.readdirSync(pluginPath).filter(file => file.endsWith(".js"));
      const pluginCount = pluginFiles.length;

      // Count total commands (dynamic from framework if available)
      const totalCommands = zk.commands ? zk.commands.length : pluginFiles.length;

      // System info
      const uptime = runtime(process.uptime());
      const ramUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
      const totalRam = (os.totalmem() / 1024 / 1024).toFixed(2);
      const hostName = os.hostname();

      // GitHub repo
      const githubRepo = "https://github.com/abdallahsalimjuma/DULLAH-XMD";

      // Update message
      let updateMessage = `*✅ Your Dullahxmd bot is up-to-date!*`;
      if (localVersion !== latestVersion) {
        updateMessage = `*😵‍💫 Your ᴅᴜʟʟᴀʜ-xᴍᴅ v² bot is outdated!*\n🔹 *Current version:* ${localVersion}\n🔹 *Latest version:* ${latestVersion}\n\n*Use .update to update.*`;
      }

      // Default pushName
      if (!pushName) pushName = "User";

      const statusMessage =
        `🌟 *Good ${new Date().getHours() < 12 ? "Morning" : "Night"}, ${pushName}!* 🌟\n\n` +
        `🤖 *Bot Name:* ᴅᴜʟʟᴀʜ-xᴍᴅ v²\n🔖 *Current Version:* ${localVersion}\n📢 *Latest Version:* ${latestVersion}\n📂 *Total Plugins:* ${pluginCount}\n🔢 *Total Commands:* ${totalCommands}\n\n` +
        `💾 *System Info:*\n⏰ *Uptime:* ${uptime}\n📟 *RAM Usage:* ${ramUsage}MB / ${totalRam}MB\n⚙️ *Host Name:* ${hostName}\n\n` +
        `📑 *Changelog:*\n${latestChangelog}\n\n` +
        `⭐ *GitHub Repo:* ${githubRepo}\n\n${updateMessage}\n\n👋🏻 *Hey! Don't forget to fork & star the repo!*`;

      // Send the status message with image
      await zk.sendMessage(
        dest,
        {
          image: { url: "https://files.catbox.moe/3v4ezj.jpeg" },
          caption: statusMessage,
          contextInfo: {
            mentionedJid: [dest],
            forwardingScore: 999,
            isForwarded: true
          }
        }
      );
    } catch (error) {
      console.error("Error fetching version info:", error);
      repondre("❌ An error occurred while checking the bot version.");
    }
  }
);
