const fs = require("fs");
const axios = require("axios");
const { zokou } = require("../framework/zokou");
const FormData = require("form-data");
const { exec } = require("child_process");

const REPLICATE_API_KEY = "r8_Wi9jnm9wUZJjCP0ivHlIn2xaR5xUmck0lnycF";

zokou({
  nomCom: "whosaid",
  categorie: "tools",
  desc: "Analyze voice for gender, emotion, etc.",
  reaction: "🎧",
}, async (dest, zk, commandeOptions) => {
  const { ms, repondre } = commandeOptions;

  // ✅ Check for valid voice note message
  if (!ms.quoted || !ms.quoted.message || (!ms.quoted.message.audioMessage && !ms.quoted.message.ptt)) {
    return await repondre("❌ Please reply to a voice note.");
  }

  try {
    // ✅ Download the voice note
    const voiceBuffer = await ms.quoted.download();
    const oggFile = "./temp.ogg";
    const mp3File = "./temp.mp3";

    fs.writeFileSync(oggFile, voiceBuffer);

    // 🔁 Convert OGG to MP3 using FFmpeg
    await new Promise((resolve, reject) => {
      exec(`ffmpeg -i ${oggFile} -ar 44100 -ac 2 ${mp3File}`, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // 📤 Upload MP3 to Replicate
    const form = new FormData();
    form.append("file", fs.createReadStream(mp3File));

    const uploadResponse = await axios.post("https://api.replicate.com/v1/files", form, {
      headers: {
        ...form.getHeaders(),
        Authorization: `Token ${REPLICATE_API_KEY}`,
      },
    });

    const audio_url = uploadResponse.data.url;

    // 🧠 Run prediction
    const predictionResponse = await axios.post("https://api.replicate.com/v1/predictions", {
      version: "f2834fc6f5c9297643d46a3de7f0f89fcfb60e8f16f70897e441cb49fb12aa8b",
      input: { audio: audio_url },
    }, {
      headers: {
        Authorization: `Token ${REPLICATE_API_KEY}`,
        "Content-Type": "application/json",
      },
    });

    const predictionId = predictionResponse.data.id;
    let output;

    // ⏳ Wait for completion
    while (true) {
      const statusCheck = await axios.get(`https://api.replicate.com/v1/predictions/${predictionId}`, {
        headers: { Authorization: `Token ${REPLICATE_API_KEY}` },
      });

      if (statusCheck.data.status === "succeeded") {
        output = statusCheck.data.output;
        break;
      }

      if (statusCheck.data.status === "failed") {
        throw new Error("Prediction failed.");
      }

      await new Promise((r) => setTimeout(r, 2000));
    }

    // ✅ Format and send response
    const result = `
🔍 *Voice Analysis Results:*
👤 *Gender:* ${output.gender}
🗣️ *Language:* ${output.language}
😡 *Emotion:* ${output.emotion}
🤖 *AI Voice:* ${output.is_ai_generated ? "Yes" : "No"}
    `.trim();

    await repondre(result);

    // 🧹 Cleanup
    fs.unlinkSync(oggFile);
    fs.unlinkSync(mp3File);
  } catch (err) {
    console.error(err);
    await repondre("❌ Failed to analyze voice. Make sure you're replying to a valid voice note.");
  }
});
