const { zokou } = require('../framework/zokou');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');
const path = require('path');

// Utility to convert stream to buffer
async function streamToBuffer(stream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', chunk => chunks.push(chunk));
        stream.on('end', () => resolve(Buffer.concat(chunks)));
        stream.on('error', reject);
    });
}
// 2. Profile Command
zokou({
    nomCom: "profile",
    categorie: "Utility",
    reaction: "👤",
    nomFichier: __filename
}, async (dest, zk, commandeOptions) => {
    const { repondre, ms, auteurMessage } = commandeOptions;

    if (dest.includes('@g.us')) {
        return repondre("❌ This command can only be used in private chats.");
    }

    try {
        const userId = dest;
        const [profilePicture, status] = await Promise.all([
            zk.profilePictureUrl(userId, 'image').catch(() => null),
            zk.fetchStatus(userId).catch(() => ({ status: "No status" }))
        ]);

        const profileMessage = `👤 *Profile Information*\n\n` +
                              `📛 *Name:* ${ms.pushName || "Unknown"}\n` +
                              `🆔 *User ID:* ${userId}\n` +
                              `📝 *Status:* ${status?.status || 'No status'}`;

        if (profilePicture) {
            await zk.sendMessage(dest, { 
                image: { url: profilePicture },
                caption: profileMessage
            });
        } else {
            await repondre(profileMessage);
        }
    } catch (err) {
        console.error("Error fetching profile:", err);
        await repondre(`❌ Error fetching profile information: ${err.message}`);
    }
});
