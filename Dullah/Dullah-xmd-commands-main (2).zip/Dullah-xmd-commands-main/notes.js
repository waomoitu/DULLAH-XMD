const { zokou } = require("../framework/zokou");
const fs = require("fs-extra");
const path = require("path");

const notesFile = path.join(__dirname, "../data/notes.json");
if (!fs.existsSync(notesFile)) fs.writeFileSync(notesFile, JSON.stringify({}));

const loadNotes = () => JSON.parse(fs.readFileSync(notesFile));
const saveNotes = (data) => fs.writeFileSync(notesFile, JSON.stringify(data, null, 2));

// ---------------- ADD NOTE ----------------
zokou({
  nomCom: "addnote",
  desc: "Add a personal note (OWNER ONLY).",
  categorie: "notes",
  fromMe: true,
  reaction: "📝"
}, async (dest, zk, options) => {
  const { repondre, arg, auteurMessage } = options;
  const text = arg.join(" ").trim();
  if (!text) return repondre("📝 Please provide text to save!\nExample: *.addnote My first note*");

  const notes = loadNotes();
  if (!notes[auteurMessage]) notes[auteurMessage] = [];
  const id = notes[auteurMessage].length ? notes[auteurMessage][notes[auteurMessage].length - 1].id + 1 : 1;
  notes[auteurMessage].push({ id, text });
  saveNotes(notes);
  repondre(`✅ Note saved!\n📄 ID: ${id}\n🗒️ Text: ${text}`);
});

// ---------------- LIST NOTES ----------------
zokou({
  nomCom: "allnote",
  desc: "Show all your saved notes (OWNER ONLY).",
  categorie: "notes",
  fromMe: true,
  reaction: "📚"
}, async (dest, zk, options) => {
  const { repondre, auteurMessage } = options;
  const notes = loadNotes()[auteurMessage] || [];
  if (!notes.length) return repondre("❌ You have no notes saved!");
  const list = notes.map(n => `🔹 *ID:* ${n.id}\n${n.text}`).join("\n\n");
  repondre(`📚 *Your Notes:*\n\n${list}`);
});

// ---------------- GET NOTE ----------------
zokou({
  nomCom: "getnote",
  desc: "Show a note by ID (OWNER ONLY).",
  categorie: "notes",
  fromMe: true,
  reaction: "🔍"
}, async (dest, zk, options) => {
  const { repondre, arg, auteurMessage } = options;
  const id = parseInt(arg[0]);
  if (!id) return repondre("⚠️ Provide a valid note ID!\nExample: *.getnote 1*");

  const notes = loadNotes()[auteurMessage] || [];
  const note = notes.find(n => n.id === id);
  if (!note) return repondre("❌ Note not found!");
  repondre(`📄 *Note ${note.id}:*\n${note.text}`);
});

// ---------------- DELETE NOTE ----------------
zokou({
  nomCom: "delnote",
  desc: "Delete a note by ID (OWNER ONLY).",
  categorie: "notes",
  fromMe: true,
  reaction: "🗑️"
}, async (dest, zk, options) => {
  const { repondre, arg, auteurMessage } = options;
  const id = parseInt(arg[0]);
  if (!id) return repondre("⚠️ Provide a valid note ID!\nExample: *.delnote 2*");

  const allNotes = loadNotes();
  const notes = allNotes[auteurMessage] || [];
  const index = notes.findIndex(n => n.id === id);
  if (index === -1) return repondre("❌ Note not found!");

  const deleted = notes.splice(index, 1)[0];
  allNotes[auteurMessage] = notes;
  saveNotes(allNotes);
  repondre(`🗑️ Note *${deleted.id}* deleted successfully!`);
});

// ---------------- DELETE ALL NOTES ----------------
zokou({
  nomCom: "delallnote",
  desc: "Delete all your notes (OWNER ONLY).",
  categorie: "notes",
  fromMe: true,
  reaction: "🧹"
}, async (dest, zk, options) => {
  const { repondre, auteurMessage } = options;
  const allNotes = loadNotes();
  allNotes[auteurMessage] = [];
  saveNotes(allNotes);
  repondre("🧹 All your notes have been deleted successfully!");
});