const { zokou } = require("../framework/zokou");
const axios = require("axios");

zokou({
  nomCom: "intro",
  desc: "Shows the intro of the bot owner.",
  categorie: "fun",
}, async (dest, zk, commandeOptions) => {
  const { repondre, ms } = commandeOptions;

  try {
    const surl = "https://github.com/abdallahsalimjuma/DULLAH-XMD";
    const name = "ᴅᴜʟʟᴀʜ xᴍᴅ";
    const body = "𝑻𝑯𝑬 𝑷𝑶𝑾𝑬𝑹 ⚡";
    const image = "https://telegra.ph/file/1e60489705c851f74b55e.jpg";

    const text = `╭═══ ━ ━ ━ ━ • ━ ━ ━ ━ ═══♡᭄
│        「 𝗠𝗬 𝗜𝗡𝗧𝗥𝗢 」
│ Name       : ᴅᴜʟʟᴀʜ xᴍᴅ
│ Place        : ᴅᴀʀ ᴇꜱ ꜱᴀʟᴀᴀᴍ 🇹🇿
│ Gender    : ᴍᴀʟᴇ
│ Age           : 25
│ Phone      : wa.me/255716945971
│ YouTube  : youtube.com/@AbdallahSalim-f5u
│ Status      : ᴅᴇᴠᴇʟᴏᴘᴇʀ | ʙᴏᴛ ᴄʀᴇᴀᴛᴏʀ
│ Channel   : https://whatsapp.com/channel/0029VbBFf4nEgGfS6bViYQ1O
│ Group       : https://chat.whatsapp.com/Ehjd0PLNVLNLtgI01Eqh8D?mode=wwc
╰═══ ━ ━ ━ ━ • ━ ━ ━ ━ ═══♡᭄`;

    await zk.sendMessage(
      dest,
      {
        image: { url: image },
        caption: text,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          externalAdReply: {
            title: name,
            body: body,
            thumbnailUrl: image,
            sourceUrl: surl,
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: ms }
    );
  } catch (e) {
    console.error("[INTRO COMMAND ERROR]", e);
    repondre(`❌ Error showing intro:\n${e.message}`);
  }
});