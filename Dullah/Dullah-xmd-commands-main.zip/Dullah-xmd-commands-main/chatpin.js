const { zokou } = require("../framework/zokou");

// Helper: format JID
function formatJid(input) {
    if (!input) return null;
    input = input.replace(/\s+/g, "");
    if (/^\d+$/.test(input)) {
        return input + "@s.whatsapp.net"; // private chat
    }
    if (/^\d+@g\.us$/.test(input)) {
        return input; // group
    }
    if (input.includes("@")) {
        return input; // already valid JID
    }
    return null; // invalid
}

// 📌 PIN CHAT
zokou(
    {
        nomCom: "chatpin",
        categorie: "tools",
        reaction: "📌",
        desc: "Pin a chat"
    },
    async (dest, zk, { repondre, msgRepondu, mention, arg, auteurMsgRepondu }) => {
        try {
            let jid;
            if (msgRepondu) {
                jid = auteurMsgRepondu;
            } else if (mention && mention.length > 0) {
                jid = mention[0];
            } else if (arg[0]) {
                jid = formatJid(arg[0]);
            } else {
                jid = dest;
            }

            jid = formatJid(jid);
            if (!jid) return repondre("⚠️ Invalid chat or JID format.");

            console.log("Attempting to pin chat:", jid);

            // Check if private chat or group
            const isPrivate = jid.endsWith("@s.whatsapp.net");

            if (isPrivate) {
                // Some WhatsApp versions don't allow pinning private chats
                return repondre("⚠️ Cannot pin private chats on this WhatsApp version.");
            }

            await zk.chatModify({ pin: true }, jid);
            await repondre(`📌 Chat *${jid.split("@")[0]}* pinned successfully ✅`);

        } catch (e) {
            console.error("Chatpin error:", e);
            await repondre(`❌ Failed to pin this chat. Reason: ${e.message || e}`);
        }
    }
);

// 📍 UNPIN CHAT
zokou(
    {
        nomCom: "unpin",
        categorie: "tools",
        reaction: "📍",
        desc: "Unpin a chat"
    },
    async (dest, zk, { repondre, msgRepondu, mention, arg, auteurMsgRepondu }) => {
        try {
            let jid;
            if (msgRepondu) {
                jid = auteurMsgRepondu;
            } else if (mention && mention.length > 0) {
                jid = mention[0];
            } else if (arg[0]) {
                jid = formatJid(arg[0]);
            } else {
                jid = dest;
            }

            jid = formatJid(jid);
            if (!jid) return repondre("⚠️ Invalid chat or JID format.");

            console.log("Attempting to unpin chat:", jid);

            const isPrivate = jid.endsWith("@s.whatsapp.net");

            if (isPrivate) {
                return repondre("⚠️ Cannot unpin private chats on this WhatsApp version.");
            }

            await zk.chatModify({ pin: false }, jid);
            await repondre(`📍 Chat *${jid.split("@")[0]}* unpinned successfully ✅`);

        } catch (e) {
            console.error("Unpin error:", e);
            await repondre(`❌ Failed to unpin this chat. Reason: ${e.message || e}`);
        }
    }
);
