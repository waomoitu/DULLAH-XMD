const { zokou } = require("../framework/zokou");
const axios = require("axios");
const translatte = require("translatte");

// ─── ROMANCE COMMAND ───
zokou(
  {
    nomCom: "romance",
    categorie: "fun",
    reaction: "❤️",
    desc: "Romantic Shayari in Roman Urdu",
  },
  async (dest, zk, { ms }) => {
    try {
      const res = await axios.get("https://farzi-vichar-api.vercel.app/category/love/random");
      console.log("API response:", res.data);

      const original = res.data.content || res.data.quote || res.data.result || "😅 No content received";

      const translation = await translatte(original, { to: "ur" });
      console.log("Translation response:", translation);

      const translatedText = translation.text || "⚠️ Translation failed";

      await zk.sendMessage(
        dest,
        { text: `❤️ *Romantic Shayari (Roman Urdu)*:\n\n${translatedText}` },
        { quoted: ms }
      );
    } catch (e) {
      console.error("Romance command error:", e);
      await zk.sendMessage(dest, { text: `❌ Error: ${e.message}` }, { quoted: ms });
    }
  }
);
