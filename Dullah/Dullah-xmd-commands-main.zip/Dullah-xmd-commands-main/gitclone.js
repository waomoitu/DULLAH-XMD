const { zokou } = require("../framework/zokou");
const fetch = require("node-fetch");

// contextInfo  channel  (DRY)
const channelInfo = {
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: "120363403345479886@newsletter",
    newsletterName: "DULLAH-XMD🤎",
    serverMessageId: -1
  }
};

zokou({
  nomCom: "gitclone",
  alias: ["git"],
  desc: "Download GitHub repository as a zip file.",
  categorie: "Downloader"
}, async (dest, zk, { ms, arg, repondre }) => {
  try {
    if (!arg[0]) {
      return zk.sendMessage(dest, { 
        text: "❌ Where is the GitHub link?\n\nExample:\n.gitclone https://github.com/username/repository", 
        contextInfo: channelInfo 
      }, { quoted: ms });
    }

    if (!/^(https:\/\/)?github\.com\/.+/.test(arg[0])) {
      return zk.sendMessage(dest, { 
        text: "⚠️ Invalid GitHub link. Please provide a valid GitHub repository URL.", 
        contextInfo: channelInfo 
      }, { quoted: ms });
    }

    const regex = /github\.com\/([^\/]+)\/([^\/]+)(?:\.git)?/i;
    const match = arg[0].match(regex);

    if (!match) {
      return zk.sendMessage(dest, { 
        text: "⚠️ Invalid GitHub URL.", 
        contextInfo: channelInfo 
      }, { quoted: ms });
    }

    const [, username, repo] = match;
    const zipUrl = `https://api.github.com/repos/${username}/${repo}/zipball`;

    const response = await fetch(zipUrl, { method: "HEAD" });
    if (!response.ok) {
      return zk.sendMessage(dest, { 
        text: "❌ Repository not found.", 
        contextInfo: channelInfo 
      }, { quoted: ms });
    }

    const contentDisposition = response.headers.get("content-disposition");
    const fileName = contentDisposition ? contentDisposition.match(/filename=(.*)/)[1] : `${repo}.zip`;

    // react 📦
    await zk.sendMessage(dest, { react: { text: "📦", key: ms.key } });

    // notify user
    await zk.sendMessage(dest, { 
      text: `📥 *Downloading repository...*\n\n*Repository:* ${username}/${repo}\n*Filename:* ${fileName}\n\n> ©Dullahxmd is Speed🔥`, 
      contextInfo: channelInfo 
    }, { quoted: ms });

    // send file
    await zk.sendMessage(dest, {
      document: { url: zipUrl },
      fileName: fileName,
      mimetype: 'application/zip',
      contextInfo: channelInfo
    }, { quoted: ms });

  } catch (e) {
    console.error(e);
    zk.sendMessage(dest, { 
      text: "❌ Failed to download the repository. Please try again later.", 
      contextInfo: channelInfo 
    }, { quoted: ms });
  }
});
