const { zokou } = require("../framework/zokou");
const conf = require("../set");

zokou(
  {
    nomCom: "owner",
    categorie: "General",
    reaction: "👑",
  },
  async (dest, zk, commandeOptions) => {
    const { ms } = commandeOptions;

    const msg = `┏━━⬣「 *DULLAH XMD* 」⬣━━┓
┃
┃ 👑 *Owner Information*
┃
┃ 🤎 *Name:* ᴅᴜʟʟᴀʜ xᴍᴅ
┃ 📞 *Contact:* wa.me/255716945971
┃ 👥 *Group:* https://chat.whatsapp.com/Dg9rNdDl1HBJ12LnOmH0oD
┃ 📺 *YouTube:* youtube.com/@abdallahsalim-f5u
┃ 🎵 *TikTok:* tiktok.com/@abdallahsalim0
┃
┗━━━━━━━━━━━━━━━━━⬣
©ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴜʟʟᴀʜ xᴍᴅ🤎`;

    try {
      // Send image with caption
      await zk.sendMessage(dest, {
        image: { url: "https://url.bwmxmd.online/Adams.m4dr7h8x.jpg" },
        caption: msg,
      }, { quoted: ms });

      // Send background intro audio
      await zk.sendMessage(dest, {
        audio: { url: "" },
        mimetype: 'audio/mp4',
        ptt: false,
      }, { quoted: ms });

    } catch (error) {
      console.error("Error sending owner command:", error);
    }
  }
);
