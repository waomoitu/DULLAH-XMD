<p align="center">
ᴅᴜʟʟᴀʜ-xᴍᴅ v²
</p>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=THANKS FOR CHOOSING +DULLAH;WHATSAPP+BOT+CREATED+BY+DULLAH" alt="Typing SVG" /></a>
  </p>

<p align="center">
  <a href="https://github.com/abdallahsalimjuma">
    <img alt="DULLA-XMD logo" height="200" src="https://files.catbox.moe/533oqh.jpg">
  </a>
</p>
  
</h1> 
<p align="center">l introduce <b>Dullah-xmd</b>, a  simple WhatsApp bot Created By Dulla</p>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{abdallahsalimjuma}/count.svg" alt="Dullah xmd :: Visitor's Count" /></p>

---

