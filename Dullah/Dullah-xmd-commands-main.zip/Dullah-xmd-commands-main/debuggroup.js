const { zokou } = require("../framework/zokou");

zokou(
  { nomCom: "debuggroup", categorie: 'tools' },
  async (dest, zk, commandeOptions) => {
    const {
      repondre,
      infosGroupe,
    } = commandeOptions;

    const groupMembers = infosGroupe.participants || [];
    const adminList = groupMembers.filter(m => m.admin !== null).map(m => `${m.id} (${m.admin})`);
    const botID = zk.user.id;

    await repondre(`🧪 *Group Debug Info:*\n\n` +
      `🤖 Bot ID: ${botID}\n` +
      `👥 Admins:\n${adminList.join("\n")}\n\n` +
      `👤 Total Members: ${groupMembers.length}`
    );
  }
);
