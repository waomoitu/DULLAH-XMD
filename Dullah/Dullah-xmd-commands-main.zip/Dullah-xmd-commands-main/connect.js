// commands/connect.js
const { zokou } = require("../framework/zokou");
const fs = require("fs");
const zlib = require("zlib");
const set = require("../set");

zokou({
  nomCom: "connect",
  desc: "Connect a new session (Owner only)",
  categorie: "owner",
  fromMe: true,
}, async (dest, zk, { repondre, arg, ms }) => {
  try {
    const sender = (ms.key.participant || ms.key.remoteJid).split("@")[0]; 

if (sender !== set.NUMERO_OWNER) {
  return repondre("🚫 This command is allowed for the owner only.");
}

    if (!arg[0]) return repondre("⚠️ Usage: .connect NAME;;;SESSION");

    const input = arg.join(" ");
    const [name, session] = input.split(";;;");

    if (!name || !session) return repondre("⚠️ Invalid format. Use: NAME;;;SESSION");

    const dir = "./sessions";
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    fs.writeFileSync(`${dir}/${name}.json`, session, "utf8");
    repondre(`✅ Session for ${name} has been successfully saved.`);

    // Hii inafanya session ya DULLAH-MD kuwa active
    if (name === "DULLAH-MD") {
      const [header, b64data] = session.split(";;;");
      if (header === "DULLAH-MD" && b64data) {
        const decompressedData = zlib.gunzipSync(Buffer.from(b64data.replace("...", ""), "base64"));
        fs.writeFileSync(__dirname + "/../auth/creds.json", decompressedData, "utf8");
        console.log(`Session for ${name} is now active.`);
      }
    }

  } catch (err) {
    console.log(err);
    repondre("❌ An error occurred while saving the session.");
  }
});
