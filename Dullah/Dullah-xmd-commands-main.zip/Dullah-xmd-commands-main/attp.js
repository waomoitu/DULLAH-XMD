// file: attp-zokou.js
const { zokou } = require('../framework/zokou');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { writeExifVid } = require('../lib/exif');

zokou(
    {
        nomCom: 'attp',
        categorie: 'fun',
        reaction: '✍️',
        alias: ['stickertext', 'textsticker'],
        desc: 'Create animated text stickers (blinking colors) from text'
    },
    async (dest, zk, { ms, arg, repondre }) => {
        try {
            const text = (arg && arg.length > 0 ? arg.join(' ') : '').trim();
            if (!text) {
                return repondre('Please provide text after the command.\nUsage: .attp <text>');
            }

            // Reaction while processing
            await zk.sendMessage(dest, { react: { text: '🔄', key: ms.key } });

            // Generate blinking video with FFmpeg
            const mp4Buffer = await renderBlinkingVideoWithFfmpeg(text);

            // Convert video to webp sticker
            const webpPath = await writeExifVid(mp4Buffer, { packname: 'Knight Bot' });
            const webpBuffer = fs.readFileSync(webpPath);
            try { fs.unlinkSync(webpPath); } catch {}

            // Send sticker
            await zk.sendMessage(dest, { sticker: webpBuffer }, { quoted: ms });

        } catch (err) {
            console.error('Error in attp-zokou command:', err);
            await repondre('❌ Failed to generate the animated sticker.');
        }
    }
);

function renderBlinkingVideoWithFfmpeg(text) {
    return new Promise((resolve, reject) => {
        const fontPath = process.platform === 'win32'
            ? 'C:/Windows/Fonts/arialbd.ttf'
            : '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';

        const escapeDrawtextText = (s) => s
            .replace(/\\/g, '\\\\')
            .replace(/:/g, '\\:')
            .replace(/,/g, '\\,')
            .replace(/'/g, "\\'")
            .replace(/\[/g, '\\[')
            .replace(/\]/g, '\\]')
            .replace(/%/g, '\\%');

        const safeText = escapeDrawtextText(text);
        const safeFontPath = process.platform === 'win32'
            ? fontPath.replace(/\\/g, '/').replace(':', '\\:')
            : fontPath;

        const cycle = 0.3;
        const dur = 1.8; // 6 cycles

        const drawRed = `drawtext=fontfile='${safeFontPath}':text='${safeText}':fontcolor=red:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='lt(mod(t\\,${cycle})\\,0.1)'`;
        const drawBlue = `drawtext=fontfile='${safeFontPath}':text='${safeText}':fontcolor=blue:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='between(mod(t\\,${cycle})\\,0.1\\,0.2)'`;
        const drawGreen = `drawtext=fontfile='${safeFontPath}':text='${safeText}':fontcolor=green:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='gte(mod(t\\,${cycle})\\,0.2)'`;

        const filter = `${drawRed},${drawBlue},${drawGreen}`;

        const args = [
            '-y',
            '-f', 'lavfi',
            '-i', `color=c=black:s=512x512:d=${dur}:r=20`,
            '-vf', filter,
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-movflags', '+faststart+frag_keyframe+empty_moov',
            '-t', String(dur),
            '-f', 'mp4',
            'pipe:1'
        ];

        const ff = spawn('ffmpeg', args);
        const chunks = [];
        const errors = [];

        ff.stdout.on('data', d => chunks.push(d));
        ff.stderr.on('data', e => errors.push(e));
        ff.on('error', reject);
        ff.on('close', code => {
            if (code === 0) return resolve(Buffer.concat(chunks));
            reject(new Error(Buffer.concat(errors).toString() || `ffmpeg exited with code ${code}`));
        });
    });
}