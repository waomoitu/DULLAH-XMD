const { zokou } = require("../framework/zokou");
const { jidNormalizedUser } = require("@whiskeysockets/baileys");

// utilities
const jidToNum = (jid) => jid.split("@")[0];
const formatTime = (timestamp) => {
  const date = new Date(timestamp * 1000);
  return date.toLocaleString();
};

zokou(
  {
    nomCom: "whois",
    categorie: "Misc",
    reaction: "👤",
    desc: "To get PP and about info (User / Group)",
  },
  async (dest, zk, { repondre, arg, msgRepondu, mention, auteurMessage, m }) => {
    try {
      let id = null;
      let gid = null;

      // 1. uki-reply message
      if (msgRepondu) {
        id = jidNormalizedUser(
          msgRepondu.jid ||
          msgRepondu.sender ||
          msgRepondu.participant ||
          msgRepondu.key?.participant
        );
      }
      // 2. uki-mention mtu
      else if (mention && mention.length > 0) {
        id = jidNormalizedUser(mention[0]);
      }
      // 3. ukiandika namba direct
      else if (arg[0]) {
        id = jidNormalizedUser(arg[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net");
      }
      // 4. inbox (chat ya mtu mmoja mmoja)
      else if (dest.endsWith("@s.whatsapp.net")) {
        id = dest;
      }
      // 5. group case
      else if (dest.endsWith("@g.us")) {
        gid = dest;
      }
      // fallback → wewe mwenyewe
      else {
        id = auteurMessage;
      }

      // profile picture
      let pp;
      try {
        pp = await zk.profilePictureUrl(id || gid, "image");
      } catch {
        pp = "https://i.ibb.co/3F3D8Jj/avatar.png";
      }

      // caption
      let caption = "";

      if (id) {
        caption = `*Num :* +${jidToNum(id)}`;
        try {
          const status = await zk.fetchStatus(id);
          const name = await zk.getName(id);
          caption += `\n*Name :* ${name}`;
          if (status?.status) {
            caption += `\n*About :* ${status.status}\n*setAt :* ${formatTime(status.setAt / 1000)}`;
          }
        } catch {
          caption += `\n*Name :* ${(await zk.getName(id)) || "Unknown"}`;
        }
      } else if (gid) {
        try {
          const metadata = await zk.groupMetadata(gid);
          caption = `*Group Name :* ${metadata.subject}\n*Owner :* ${metadata.owner ? "+" + jidToNum(metadata.owner) : "Unknown"}\n*Members :* ${metadata.participants.length}\n*Created :* ${formatTime(metadata.creation)}\n*Desc :* ${metadata.desc || "No description"}`;
        } catch {
          caption = "❌ Failed to get group metadata";
        }
      }

      // send
      return await zk.sendMessage(
        dest,
        pp ? { image: { url: pp }, caption } : { text: caption },
        { quoted: m }
      );

    } catch (err) {
      return repondre("❌ Failed to fetch info: " + err.message);
    }
  }
);
