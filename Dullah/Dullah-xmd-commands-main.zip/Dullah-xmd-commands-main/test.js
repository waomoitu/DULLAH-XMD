"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

const { zokou } = require("../framework/zokou");

zokou(
  {
    nomCom: "test",
    reaction: "✅",
    nomFichier: __filename,
  },
  async (dest, zk, commandeOptions) => {
    const message =
      "🌟 Hi. I am 👑 *DULLAH-XMD*, a friendly multi-device WhatsApp bot from **Tanzania🇹🇿**, proudly created by **Mr. Dullah**.\n\n" +
      "✅ *System Test:* **SUCCESSFUL**\n" +
      "Everything is working perfectly on the system. 💯\n\n" +
      "Thanks for using **DULLAH-XMD** — Stay connected and smart! 🧠🚀";

    const imageUrl = "https://files.catbox.moe/533oqh.jpg";
    const audioUrl = "https://files.catbox.moe/eoyls3.mp3";

    // Send image with caption
    const sentMsg = await zk.sendMessage(dest, {
      image: { url: imageUrl },
      caption: message,
    });

    // Wait a short time to ensure image is sent before replying with audio
    await new Promise((resolve) => setTimeout(resolve, 300));

    // Send the audio as a reply to the image message
    await zk.sendMessage(dest, {
      audio: { url: audioUrl },
      mimetype: "audio/mp4",
      ptt: true, // voice note
      contextInfo: {
        quotedMessage: sentMsg.message,
        stanzaId: sentMsg.key.id,
        participant: sentMsg.key.participant || commandeOptions.participant || undefined,
      },
    });
  }
);

console.log("DULLAH-XMD test command loaded successfully");
