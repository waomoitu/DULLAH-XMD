const { zokou } = require("../framework/zokou");
const eco = require("../lib/economy");

zokou({
    nomCom: "wallet",
    desc: "Shows your wallet balance.",
    categorie: "Economy",
    reaction: "💷"
}, async (dest, zk, commandeOptions) => {
    const { repondre, auteurMessage, nomAuteurMessage } = commandeOptions;

    try {
        const balance = await eco.balance(auteurMessage);

        let msg = `*👛 ${nomAuteurMessage}'s Wallet:*\n\n` +
                  `💰 Wallet: _🪙${balance.wallet}_\n` +
                  `🏦 Bank: _🪙${balance.bank}_ / ${balance.bankCapacity}`;

        repondre(msg);
    } catch (e) {
        repondre(`${e}\n\ncommand: wallet`);
    }
});
