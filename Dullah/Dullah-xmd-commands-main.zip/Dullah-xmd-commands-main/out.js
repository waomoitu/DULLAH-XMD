const { zokou } = require("../framework/zokou");
const { Sticker, StickerTypes } = require("wa-sticker-formatter");
const fs = require("fs");

zokou(
  { nomCom: "out", categorie: 'Group', reaction: "🤦" },
  async (dest, zk, commandeOptions) => {
    const {
      repondre,
      msgRepondu,
      infosGroupe,
      auteurMsgRepondu,
      verifGroupe,
      nomAuteurMessage,
      auteurMessage,
      superUser
    } = commandeOptions;

    if (!verifGroupe) return repondre("❌ This command only works in groups.");
    if (!msgRepondu || typeof auteurMsgRepondu !== "string") {
      return repondre("❗ Please reply to the message of the member you want to remove.");
    }

    const groupMembers = infosGroupe.participants || [];

    const getAdmins = (members) =>
      members.filter(m => m.admin !== null).map(m => m.id);

    const isMember = (user) =>
      groupMembers.some(m => m.id === user);

    const adminList = getAdmins(groupMembers);

    const botId = zk.user.id; // full ID e.g., 2557...@s.whatsapp.net
    const isBotAdmin = groupMembers.find(p => p.id === botId)?.admin !== null;
    const isAuthorAdmin = groupMembers.find(p => p.id === auteurMessage)?.admin !== null;
    const isTargetAdmin = groupMembers.find(p => p.id === auteurMsgRepondu)?.admin !== null;
    const isTargetMember = isMember(auteurMsgRepondu);

    console.log("🤖 Bot ID:", botId);
    console.log("✅ Bot Admin?:", isBotAdmin);
    console.log("👤 Author Admin?:", isAuthorAdmin);
    console.log("🎯 Target Admin?:", isTargetAdmin);

    if (!isAuthorAdmin && !superUser) {
      return repondre("⚠️ You must be a group admin to use this command.");
    }

    if (!isBotAdmin) {
      return repondre("⚠️ I must be an admin to remove someone from this group.");
    }

    if (!isTargetMember) {
      return repondre("❌ That user is not in this group.");
    }

    if (isTargetAdmin) {
      return repondre("⚠️ I can't remove that member. They are an admin.");
    }

    try {
      const gifLink = "https://raw.githubusercontent.com/djalega8000/Zokou-MD/main/media/remover.gif";
      const sticker = new Sticker(gifLink, {
        pack: 'DULLAH-XMD',
        author: nomAuteurMessage,
        type: StickerTypes.FULL,
        categories: ['🔥', '👋'],
        id: 'bye123',
        quality: 70,
        background: '#000000'
      });

      await sticker.toFile("st.webp");

      // Remove user
      await zk.groupParticipantsUpdate(dest, [auteurMsgRepondu], "remove");

      const targetNumber = auteurMsgRepondu.split("@")[0];
      const goodbyeMsg = `👋 *DULLAH XMD*: @${targetNumber} has been removed from the group. We wish them peace wherever they go.`;

      // Send sticker
      if (msgRepondu?.key) {
        await zk.sendMessage(dest, { sticker: fs.readFileSync("st.webp") }, { quoted: msgRepondu });
      } else {
        await zk.sendMessage(dest, { sticker: fs.readFileSync("st.webp") });
      }

      // Send goodbye message
      await zk.sendMessage(dest, { text: goodbyeMsg, mentions: [auteurMsgRepondu] });

      fs.unlinkSync("st.webp");

    } catch (e) {
      console.error("❌ Removal Error:", e);
      repondre("❌ Error while removing member: " + (e.message || e));
    }
  }
);
